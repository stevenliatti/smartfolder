var wrapper_8h =
[
    [ "_GNU_SOURCE", "wrapper_8h.html#a369266c24eacffb87046522897a570d5", null ],
    [ "_XOPEN_SOURCE", "wrapper_8h.html#a78c99ffd76a7bb3c8c74db76207e9ab4", null ],
    [ "_access", "wrapper_8h.html#a3b42d5ff7f54f65dd337d964c12670f3", null ],
    [ "_fork", "wrapper_8h.html#af567c11fe2d7df8f0e4d8440850e26ef", null ],
    [ "_kill", "wrapper_8h.html#aea4fc7643f2a2aacc79a377ffb7be528", null ],
    [ "_rmdir", "wrapper_8h.html#a4de673e89ea25b764ccb52a18e5b1cf0", null ],
    [ "_symlink", "wrapper_8h.html#ad4b966b03c0085950f3ef9a45f2d688d", null ],
    [ "_unlink", "wrapper_8h.html#a11bde836cab6ec72897ede2286350e72", null ]
];