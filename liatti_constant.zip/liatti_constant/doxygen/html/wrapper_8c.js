var wrapper_8c =
[
    [ "_access", "wrapper_8c.html#a3b42d5ff7f54f65dd337d964c12670f3", null ],
    [ "_fork", "wrapper_8c.html#af567c11fe2d7df8f0e4d8440850e26ef", null ],
    [ "_kill", "wrapper_8c.html#aea4fc7643f2a2aacc79a377ffb7be528", null ],
    [ "_rmdir", "wrapper_8c.html#a4de673e89ea25b764ccb52a18e5b1cf0", null ],
    [ "_symlink", "wrapper_8c.html#ad4b966b03c0085950f3ef9a45f2d688d", null ],
    [ "_unlink", "wrapper_8c.html#a11bde836cab6ec72897ede2286350e72", null ]
];