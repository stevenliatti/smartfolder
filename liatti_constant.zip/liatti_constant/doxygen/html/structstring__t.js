var structstring__t =
[
    [ "state", "structstring__t.html#af28c105b7bdf672327912dd0c526cf1d", null ],
    [ "string", "structstring__t.html#aed1cfb225a5fb77461e7972691e68a72", null ]
];