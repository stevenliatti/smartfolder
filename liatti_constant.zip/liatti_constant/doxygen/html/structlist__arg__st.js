var structlist__arg__st =
[
    [ "next", "structlist__arg__st.html#a6fb953e03c017d2107412ea58fa827fd", null ],
    [ "value", "structlist__arg__st.html#a7e8429e961df1a10fbe16db590f63d58", null ]
];