var searchData=
[
  ['regex_5fmatch',['regex_match',['../parser_8c.html#aea5246a4f2b3acb8d1cf9e18748ca4ec',1,'regex_match(char *request, char *regex):&#160;parser.c'],['../parser_8h.html#aea5246a4f2b3acb8d1cf9e18748ca4ec',1,'regex_match(char *request, char *regex):&#160;parser.c']]],
  ['remove_5fhead_5flist',['remove_head_list',['../list__bool_8c.html#a1cafc1732657a98bb0ed1a8cd8c70fd9',1,'remove_head_list(list_bool_t *list):&#160;list_bool.c'],['../list__bool_8h.html#a1cafc1732657a98bb0ed1a8cd8c70fd9',1,'remove_head_list(list_bool_t *list):&#160;list_bool.c']]],
  ['remove_5fhead_5flist_5fbool',['remove_head_list_bool',['../list__bool_8c.html#a77fa2f291fe11f6d46300a0b896f1843',1,'remove_head_list_bool(list_bool_t *list, bool *value):&#160;list_bool.c'],['../list__bool_8h.html#a77fa2f291fe11f6d46300a0b896f1843',1,'remove_head_list_bool(list_bool_t *list, bool *value):&#160;list_bool.c']]],
  ['remove_5fsearchfolder',['remove_searchfolder',['../searchfolder_8c.html#ac89d05eabd54c2e68bbfe31028cbaa6a',1,'remove_searchfolder(const char *path):&#160;searchfolder.c'],['../test__remove__searchfolder_8c.html#ac89d05eabd54c2e68bbfe31028cbaa6a',1,'remove_searchfolder(const char *path):&#160;test_remove_searchfolder.c']]],
  ['resize',['resize',['../hash__table_8c.html#a45febc81184307ecff9ff86b0df47263',1,'hash_table.c']]]
];
