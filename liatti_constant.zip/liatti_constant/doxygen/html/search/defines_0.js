var searchData=
[
  ['_5fgnu_5fsource',['_GNU_SOURCE',['../wrapper_8h.html#a369266c24eacffb87046522897a570d5',1,'wrapper.h']]],
  ['_5fxopen_5fsource',['_XOPEN_SOURCE',['../wrapper_8h.html#a78c99ffd76a7bb3c8c74db76207e9ab4',1,'wrapper.h']]]
];
