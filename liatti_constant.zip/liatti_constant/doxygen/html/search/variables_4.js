var searchData=
[
  ['next',['next',['../structlist__arg__st.html#a6fb953e03c017d2107412ea58fa827fd',1,'list_arg_st::next()'],['../structlist__bool__st.html#a475d7b8f131b46e18662361d53ac6476',1,'list_bool_st::next()']]]
];
