var searchData=
[
  ['_5faccess',['_access',['../wrapper_8c.html#a3b42d5ff7f54f65dd337d964c12670f3',1,'_access(const char *name, int mode):&#160;wrapper.c'],['../wrapper_8h.html#a3b42d5ff7f54f65dd337d964c12670f3',1,'_access(const char *name, int mode):&#160;wrapper.c']]],
  ['_5ffork',['_fork',['../wrapper_8c.html#af567c11fe2d7df8f0e4d8440850e26ef',1,'_fork():&#160;wrapper.c'],['../wrapper_8h.html#af567c11fe2d7df8f0e4d8440850e26ef',1,'_fork():&#160;wrapper.c']]],
  ['_5fgnu_5fsource',['_GNU_SOURCE',['../wrapper_8h.html#a369266c24eacffb87046522897a570d5',1,'wrapper.h']]],
  ['_5fkill',['_kill',['../wrapper_8c.html#aea4fc7643f2a2aacc79a377ffb7be528',1,'_kill(pid_t pid, int sig):&#160;wrapper.c'],['../wrapper_8h.html#aea4fc7643f2a2aacc79a377ffb7be528',1,'_kill(pid_t pid, int sig):&#160;wrapper.c']]],
  ['_5frmdir',['_rmdir',['../wrapper_8c.html#a4de673e89ea25b764ccb52a18e5b1cf0',1,'_rmdir(const char *path):&#160;wrapper.c'],['../wrapper_8h.html#a4de673e89ea25b764ccb52a18e5b1cf0',1,'_rmdir(const char *path):&#160;wrapper.c']]],
  ['_5fsymlink',['_symlink',['../wrapper_8c.html#ad4b966b03c0085950f3ef9a45f2d688d',1,'_symlink(const char *oldpath, const char *newpath):&#160;wrapper.c'],['../wrapper_8h.html#ad4b966b03c0085950f3ef9a45f2d688d',1,'_symlink(const char *oldpath, const char *newpath):&#160;wrapper.c']]],
  ['_5funlink',['_unlink',['../wrapper_8c.html#a11bde836cab6ec72897ede2286350e72',1,'_unlink(const char *path):&#160;wrapper.c'],['../wrapper_8h.html#a11bde836cab6ec72897ede2286350e72',1,'_unlink(const char *path):&#160;wrapper.c']]],
  ['_5fxopen_5fsource',['_XOPEN_SOURCE',['../wrapper_8h.html#a78c99ffd76a7bb3c8c74db76207e9ab4',1,'wrapper.h']]]
];
