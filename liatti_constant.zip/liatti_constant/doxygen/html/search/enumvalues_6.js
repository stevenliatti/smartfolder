var searchData=
[
  ['more_5fop',['more_op',['../argument_8h.html#a0523ecedda95b58ee5f897f531d6211ea181941f4066f93c272513e0e5a31cdc4',1,'argument.h']]]
];
