var searchData=
[
  ['new_5flist',['new_list',['../list__bool_8c.html#ab77ea3bab296395e98e005da212db829',1,'new_list():&#160;list_bool.c'],['../list__bool_8h.html#ab77ea3bab296395e98e005da212db829',1,'new_list():&#160;list_bool.c']]]
];
