var searchData=
[
  ['string_5ft',['string_t',['../structstring__t.html',1,'']]]
];
