var logger_8c =
[
    [ "logger", "logger_8c.html#a71d55f7744b79bf8871c21d28581cc73", null ]
];