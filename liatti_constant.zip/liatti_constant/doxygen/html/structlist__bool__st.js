var structlist__bool__st =
[
    [ "next", "structlist__bool__st.html#a475d7b8f131b46e18662361d53ac6476", null ],
    [ "value", "structlist__bool__st.html#a0376be5904d0dd864b7d97c9ce1295ab", null ]
];