var NAVTREE =
[
  [ "Smart Folder", "index.html", [
    [ "Rapport d'implémentation", "index.html", [
      [ "Manuel d'utilisation", "index.html#man", null ],
      [ "Searchfolder", "index.html#searchfolder", null ],
      [ "Lecture des arguments", "index.html#argumenth", [
        [ "Arguments", "index.html#argumenth_arg", null ],
        [ "Parser", "index.html#argumenth_parser", [
          [ "-name", "index.html#parser_name", null ],
          [ "-name_contain", "index.html#parser_name_contain", null ],
          [ "-size", "index.html#parser_size", null ],
          [ "-date", "index.html#parser_date", null ],
          [ "-owner", "index.html#parser_owner", null ],
          [ "-perm", "index.html#parser_perm", null ],
          [ "Opérateurs", "index.html#parser_logic_op", null ],
          [ "Exemples d'utilisation", "index.html#parser_examples", null ]
        ] ]
      ] ],
      [ "Moteur de recherche", "index.html#search_engine", [
        [ "Crawler", "index.html#search_engine_crawler", null ],
        [ "Filter", "index.html#search_engine_filter", null ],
        [ "Linker", "index.html#search_engine_linker", null ]
      ] ],
      [ "Structures de données et librairies", "index.html#librairies", [
        [ "Tables de hash", "index.html#librairies_hash_table", [
          [ "Fonctions de hash", "index.html#hash_functions", null ]
        ] ],
        [ "Fonctions pour le hash", "index.html#librairies_hash_functions", [
          [ "Gestion des tables", "index.html#hash_tables", null ]
        ] ],
        [ "Liste/Pile de booleans ou d'arguments", "index.html#librairies_list", [
          [ "Liste/Pile de booleans", "index.html#list_bool", null ],
          [ "Liste/Pile d'arguments", "index.html#list_arg", null ]
        ] ]
      ] ],
      [ "Logger et appels système", "index.html#system_layer", [
        [ "Logger", "index.html#system_layer_logger", null ],
        [ "Wrapper", "index.html#system_layer_wrapper", null ]
      ] ],
      [ "Tests", "index.html#tests", null ]
    ] ],
    [ "Bug List", "bug.html", null ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';