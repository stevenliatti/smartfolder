var test__remove__searchfolder_8c =
[
    [ "main", "test__remove__searchfolder_8c.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "remove_searchfolder", "test__remove__searchfolder_8c.html#ac89d05eabd54c2e68bbfe31028cbaa6a", null ]
];