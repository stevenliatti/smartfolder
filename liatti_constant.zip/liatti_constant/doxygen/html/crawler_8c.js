var crawler_8c =
[
    [ "crawler", "crawler_8c.html#ae410de78153f20ba92feb7d1d2f53ebb", null ],
    [ "is_dir", "crawler_8c.html#a27082a33edf33600d33cf539dafd2e9c", null ]
];