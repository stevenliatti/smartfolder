var list__bool_8c =
[
    [ "count", "list__bool_8c.html#a402bef0501d4d160ea5a35b985c8767a", null ],
    [ "free_all_list", "list__bool_8c.html#a4e80d89873eb727deb179bebe45e85d6", null ],
    [ "insert_head", "list__bool_8c.html#afe3f5213919d8ff33eb2753bfd402fed", null ],
    [ "insert_tail", "list__bool_8c.html#a7297fc71eb504cace418d5eec6b5e4a0", null ],
    [ "is_empty", "list__bool_8c.html#a543d1d64bc87851d34c84a4fac8ee291", null ],
    [ "new_list", "list__bool_8c.html#ab77ea3bab296395e98e005da212db829", null ],
    [ "remove_head_list", "list__bool_8c.html#a1cafc1732657a98bb0ed1a8cd8c70fd9", null ],
    [ "remove_head_list_bool", "list__bool_8c.html#a77fa2f291fe11f6d46300a0b896f1843", null ]
];