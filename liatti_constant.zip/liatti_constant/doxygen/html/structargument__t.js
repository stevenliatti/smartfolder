var structargument__t =
[
    [ "flag", "structargument__t.html#a067218b020d973a6445a642d49ebfc16", null ],
    [ "oper", "structargument__t.html#ae9fb00d0047e86ef398669059e6c09b4", null ],
    [ "string", "structargument__t.html#a599ac9672c5ed92e22c3259396cbb7d8", null ],
    [ "type", "structargument__t.html#afeac3d5ed44797dfaf3a0624806aa9e6", null ]
];