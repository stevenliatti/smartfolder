var searchfolder_8c =
[
    [ "CRAWL_TIME", "searchfolder_8c.html#a6c76311c97837c1d7d57cafaf09b4354", null ],
    [ "main", "searchfolder_8c.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "remove_searchfolder", "searchfolder_8c.html#ac89d05eabd54c2e68bbfe31028cbaa6a", null ]
];